#!/bin/bash

echo "Pulling aplication"
cd /home/ubuntu/thegoat-backend
docker compose --file docker-compose.yml pull
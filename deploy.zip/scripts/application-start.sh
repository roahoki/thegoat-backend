#!/bin/bash

echo "Aplication starting"
cd /home/ubuntu/thegoat-backend
docker compose --file docker-compose.yml up -d
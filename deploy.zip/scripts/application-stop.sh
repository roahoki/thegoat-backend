#!/bin/bash
cd /home/ubuntu/thegoat-backend
echo "Stop Aplication"
docker compose --file docker-compose.yml down
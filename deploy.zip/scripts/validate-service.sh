#!/bin/bash
cd /home/ubuntu/thegoat-backend

echo "Validating service"
# Agregar mas 